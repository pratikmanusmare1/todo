<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Todo;

class TodoController extends Controller
{
   
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Todo::where('status', 0)->latest()->get();
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row) {
                    $btn = '<a href="javascript:void(0)" data-id="'.$row->id.'" class="btn btn-primary btn-sm editProduct">Edit</a>';
                    $btn .= ' <a href="javascript:void(0)" data-id="'.$row->id.'" class="btn btn-danger btn-sm deleteProduct">Delete</a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('todo.index');
    }

    public function store(Request $request)
    {
        Todo::updateOrCreate(
            
            ['id' => $request->product_id],
            ['title' => $request->title]
        );

        return response()->json(['success' => 'Product saved successfully.']);
    }

    public function edit($id)
    {
        $product = Todo::find($id);
        return response()->json($product);
    }

    public function update(Request $request, $id)
    {
        $product = Todo::find($id);
        $product->update([
            'title' => $request->title,
            // 'description' => $request->description
        ]);

        return response()->json(['success' => 'Product updated successfully.']);
    }

    public function complete(Request $request, $id)
{
    $task = Todo::findOrFail($id);
    $task->status = $request->status;
    $task->save();

    return response()->json(['success' => 'Status updated successfully.']);
}


    public function destroy($id)
    {
        Todo::find($id)->delete();
        return response()->json(['success' => 'Product deleted successfully.']);
    }

    public function completedTasks(Request $request)
{
    if ($request->ajax()) {
        $data = Todo::where('status', 1)->latest()->get();
        return DataTables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row) {
                $btn = '<a href="javascript:void(0)" data-id="'.$row->id.'" class="btn btn-primary btn-sm editProduct">Edit</a>';
                $btn .= ' <a href="javascript:void(0)" data-id="'.$row->id.'" class="btn btn-danger btn-sm deleteProduct">Delete</a>';
                return $btn;
            })
            ->rawColumns(['action'])
            ->make(true);
    }
    return view('todo.completed');
}


}