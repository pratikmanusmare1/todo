<!DOCTYPE html>
<html>
<head>
    <title>Laravel AJAX CRUD with DataTables</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Laravel AJAX CRUD with DataTables</h2>
    <a class="btn btn-success mb-3" href="javascript:void(0)" id="createNewtask"> Create New Product</a>

    <table class="table table-bordered data-table">
        <thead>
            <form action="">
            <tr>
            
                <th>No</th>
                <th>Title</th>
                <th>Time</th>
                <th>Status</th>
            </tr>
            </form>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>

</body>
</html>
