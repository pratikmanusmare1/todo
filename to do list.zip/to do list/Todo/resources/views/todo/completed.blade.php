<!DOCTYPE html>
<html>
<head>
    <title>Pratik Ajax Crud</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <!-- <a class="btn btn-primary mb-3" href="javascript:void(0)" id="createNewtask"> Create New Task</a>
    <a class="btn btn-primary mb-3" href="javascript:void(0)" id="viewCompletedTasks"> View Complete Task</a> -->
    <a class="btn btn-primary mb-3" href="{{ route('todo.index') }}" >Back</a>

    <table class="table table-bordered data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Title</th>
                <th>Time</th>
                <th>Status</th>
                <th  class="d-none">Action</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>

<script>
$(function () {
    $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

    var table = $('.data-table').DataTable({
    processing: true,
    serverSide: true,
    ajax: "{{ route('todo.completed') }}",
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex' },
        { data: 'title', name: 'title' },
        { 
            data: 'created_at', 
            name: 'created_at',
            render: function(data) {
                return moment(data).fromNow();
            }
        },
        { data: 'status', name: 'status', orderable: false, searchable: false },
        { data: 'action', name: 'action', orderable: false, searchable: false }
    ]
});




    // $('#createNewtask').click(function () {
    //     $('#saveBtn').val("create-task");
    //     $('#task_id').val('');
    //     $('#taskForm').trigger("reset");
    //     $('#modelHeading').html("Create New Task");
    //     $('#ajaxModel').modal('show');
    // });

    // $('#saveBtn').click(function (e) {
    //     e.preventDefault();
    //     $.ajax({
    //         data: $('#taskForm').serialize(),
    //         url: "{{ route('todo.store') }}",
    //         type: "POST",
    //         success: function () {
    //             $('#taskForm').trigger("reset");
    //             $('#ajaxModel').modal('hide');
    //             table.draw();
    //         }
    //     });
    // });

    // function updateTaskStatus(task_id, status) {
    //     $.ajax({
    //         type: "PUT",
    //         url: "{{ route('todo.complete', '') }}/" + task_id,
    //         data: { status: status },
    //         success: function () { table.draw(); }
    //     });
    // }

    // $('body').on('change', '.status-checkbox', function () {
    //     var task_id = $(this).data("id");
    //     var status = $(this).is(':checked') ? 1 : 0;
    //     updateTaskStatus(task_id, status);
    // });

    // $('body').on('click', '.deleteTask', function () {
    //     var task_id = $(this).data("id");
    //     if (confirm("Are You sure want to delete?")) {
    //         $.ajax({ type: "DELETE", url: "{{ route('todo.destroy', '') }}/" + task_id, success: function () { table.draw(); } });
    //     }
    // });

    // $('#viewCompletedTasks').click(function () {
    // $.ajax({
    //     url: "{{ route('todo.completed') }}",
    //     type: "GET",
    //     success: function (response) {
    //         window.location.href = "{{ route('todo.completed') }}";
    //     }
    // });
// });

});
</script>

</body>
</html>
