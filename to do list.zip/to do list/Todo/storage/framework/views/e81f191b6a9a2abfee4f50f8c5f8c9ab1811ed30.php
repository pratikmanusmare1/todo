<!DOCTYPE html>
<html>
<head>
    <title>Laravel AJAX CRUD with DataTables</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <a class="btn btn-primary mb-3" href="javascript:void(0)" id="createNewtask"> Create New Task</a>
    <a class="btn btn-primary mb-3" href="javascript:void(0)" id="viewCompletedTasks"> View Complete Task</a>

    <table class="table table-bordered data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Title</th>
                <th>Time</th>
                <th>Status</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="ajaxModel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <form id="taskForm">
                    <input type="hidden" name="task_id" id="task_id">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <button type="submit" class="btn btn-primary" id="saveBtn">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>

<script>
$(function () {
    $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('todo.index')); ?>",
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            { data: 'title', name: 'title' },
            { 
                data: 'created_at', 
                name: 'created_at',
                render: function(data) {
                    return moment(data).fromNow();
                }
            },
            { 
                data: 'status', 
                name: 'status',
                render: function(data, type, row) {
                    return `<input type='checkbox' class='status-checkbox' data-id='${row.id}' ${data ? 'checked' : ''}>`;
                }
            },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });

    $('#createNewtask').click(function () {
        $('#saveBtn').val("create-task");
        $('#task_id').val('');
        $('#taskForm').trigger("reset");
        $('#modelHeading').html("Create New Task");
        $('#ajaxModel').modal('show');
    });

    $('#saveBtn').click(function (e) {
        e.preventDefault();
        $.ajax({
            data: $('#taskForm').serialize(),
            url: "<?php echo e(route('todo.store')); ?>",
            type: "POST",
            success: function () {
                $('#taskForm').trigger("reset");
                $('#ajaxModel').modal('hide');
                table.draw();
            }
        });
    });

    function updateTaskStatus(task_id, status) {
        $.ajax({
            type: "PUT",
            url: "<?php echo e(route('todo.complete', '')); ?>/" + task_id,
            data: { status: status },
            success: function () { table.draw(); }
        });
    }

    $('body').on('change', '.status-checkbox', function () {
        var task_id = $(this).data("id");
        var status = $(this).is(':checked') ? 1 : 0;
        updateTaskStatus(task_id, status);
    });

    $('body').on('click', '.deleteTask', function () {
        var task_id = $(this).data("id");
        if (confirm("Are You sure want to delete?")) {
            $.ajax({ type: "DELETE", url: "<?php echo e(route('todo.destroy', '')); ?>/" + task_id, success: function () { table.draw(); } });
        }
    });

    $('#viewCompletedTasks').click(function () {
    $.ajax({
        url: "<?php echo e(route('todo.completed')); ?>",
        type: "GET",
        success: function (response) {
            window.location.href = "<?php echo e(route('todo.completed')); ?>";
        }
    });
});

});
</script>

</body>
</html>
<?php /**PATH F:\laravel 9\Todo\resources\views/todo/index.blade.php ENDPATH**/ ?>