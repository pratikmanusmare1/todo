<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AJAX Redirect in Laravel</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    
    <button id="redirectButton" class="btn btn-primary">Click Me</button>
    
    <script>
        $(document).ready(function(){
            $("#redirectButton").click(function(e){
                e.preventDefault(); // Prevent default behavior
                
                $.ajax({
                    url: "", // Add the Laravel route
                    type: "GET",
                    success: function(response){
                        // Redirect on success
                        window.location.href = "<?php echo e(route('todo.index')); ?>"; 
                    },
                    error: function(){
                        alert("Something went wrong!");
                    }
                });
            });
        });
    </script>

</body>
</html>
<?php /**PATH F:\to do list\Todo\resources\views/welcome.blade.php ENDPATH**/ ?>